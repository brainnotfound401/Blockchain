import Form from "@/components/Form";
import PageTitle from "@/components/PageTitle";
import { featuredEvent } from "@/data/site";
export const metadata = { title: "Upcoming events" };
export default function Events() { // TODO: event list from a data file with filters, plus /events/[slug] detail template
  return (<div className="mx-auto max-w-3xl px-4 pb-16 pt-24 md:pt-28"><div className="mb-10"><PageTitle title="Upcoming events" intro={`${featuredEvent.title}: ${featuredEvent.venue}`} /></div>
    <Form type="event" submit="Register" fields={[{ name: "name", label: "Name", required: true }, { name: "email", label: "Email", type: "email", required: true }, { name: "event", label: "Event", options: [featuredEvent.title] }]} /></div>);
}
