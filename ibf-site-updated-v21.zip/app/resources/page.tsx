"use client";
import { useState } from "react";
import Page from "@/components/Page";
import GlassButton from "@/components/GlassButton";
import { resources } from "@/data/pages";
export default function Resources() {
  const cats = ["All", ...Array.from(new Set(resources.map(r => r.c)))];
  const [cat, setCat] = useState("All"); const [q, setQ] = useState("");
  const list = resources.filter(r => (cat === "All" || r.c === cat) && r.t.toLowerCase().includes(q.toLowerCase()));
  return (<Page title="Resources" intro="Curated learning material for every stage.">
    <div className="flex flex-wrap gap-2"><input aria-label="Search resources" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} className="rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-white" />
      {cats.map(c => <GlassButton key={c} height={42} onClick={() => setCat(c)} pressed={cat === c} tone={cat === c ? "blue" : "clear"}>{c}</GlassButton>)}</div>
    <ul className="grid gap-4 md:grid-cols-3">{list.map(r => <li key={r.t} className="glass p-5"><a href={r.u} className="text-white hover:text-ember">{r.t}</a><p className="text-sm">{r.c}</p></li>)}</ul>
    {!list.length && <p>No matches. Try another category or search term.</p>}</Page>);
}
