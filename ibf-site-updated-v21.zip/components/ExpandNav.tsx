"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import GlassSurface from "./GlassSurface";

type Item = { label: string; href: string; children?: { label: string; href: string }[] };

/**
 * Collapsed: just an "IBF" pill. Click it and it expands into the full top bar;
 * move the mouse out of the bar (or tap outside / press Esc / pick a link) and it shrinks back to "IBF".
 * Desktop: the glass bar grows sideways. Phones/tablets: a panel drops down under the button.
 */
export default function ExpandNav({ items, cta }: { items: Item[]; cta: { label: string; href: string } }) {
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);
  const linksRef = useRef<HTMLUListElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const path = usePathname();
  const isHome = path === "/";   // home: small IBF button that expands. Other pages: the full bar is always visible (desktop).

  const all: Item[] = [{ label: "Home", href: "/" }, ...items];

  useEffect(() => setOpen(false), [path]);                                    // collapse after navigating
  useEffect(() => {
    if (!open) return;
    const down = (e: PointerEvent) => { if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(false); };
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("pointerdown", down); window.addEventListener("keydown", key);
    return () => { document.removeEventListener("pointerdown", down); window.removeEventListener("keydown", key); };
  }, [open]);

  const cancel = () => { if (timer.current) { clearTimeout(timer.current); timer.current = null; } };
  const leave = () => { cancel(); timer.current = setTimeout(() => setOpen(false), 220); };   // hover out -> back to "IBF"

  const pill = "rounded-full border border-white/20 bg-[rgba(10,9,24,.55)] shadow-lg shadow-black/20 backdrop-blur-xl";
  const ibfBtn = (
    <button type="button" aria-label="IBF menu" aria-expanded={open} onClick={() => setOpen(o => !o)}
      className="shrink-0 rounded-full px-5 py-2.5 font-display text-lg font-bold leading-none tracking-wide text-white transition active:scale-95 hover:text-ember focus-visible:outline focus-visible:outline-2 focus-visible:outline-ember">
      IBF
    </button>);

  return (
    <div ref={wrap} className="pointer-events-auto relative w-fit lg:pointer-events-none lg:w-full" onMouseEnter={cancel} onMouseLeave={leave}>
      {/* desktop: home page = small round IBF button (click to expand the bar); every other page = the full glass top bar, always visible */}
      <div className="hidden lg:block">
        {isHome && !open ? (
          <button type="button" aria-label="IBF menu" aria-expanded={false} onClick={() => setOpen(true)}
            className="pointer-events-auto rounded-full border border-white/25 bg-[rgba(10,9,24,.6)] px-6 py-2.5 font-display text-lg font-bold leading-none tracking-wide text-white shadow-lg shadow-black/30 backdrop-blur-xl transition duration-200 [box-shadow:inset_0_1px_0_rgba(255,255,255,.18),0_8px_24px_-8px_rgba(0,0,0,.6)] hover:border-ember/70 hover:bg-white/10 hover:text-ember active:scale-95 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ember">
            IBF
          </button>
        ) : (
          <div className="pointer-events-auto">
            <GlassSurface width="100%" height="auto" borderRadius={28} backgroundOpacity={0.12} distortionScale={-110} displace={0.5} blur={14}
              style={{ overflow: "visible", background: "rgba(10,9,24,.45)" }}>
              <nav aria-label="Main" className="flex w-full flex-nowrap items-center justify-between gap-4 px-3 py-1.5">
                {isHome
                  ? <button type="button" aria-label="Minimize menu" aria-expanded onClick={() => setOpen(false)} className="shrink-0 font-display text-lg font-bold text-white hover:text-ember focus-visible:outline focus-visible:outline-2 focus-visible:outline-ember">IBF</button>
                  : <Link href="/" aria-label="IBF home" className="shrink-0 font-display text-lg font-bold text-white hover:text-ember focus-visible:outline focus-visible:outline-2 focus-visible:outline-ember">IBF</Link>}
                <ul className="flex w-max shrink-0 items-center justify-end gap-x-5 text-sm">
                  {items.map(n => (
                    <li key={n.label} className="group relative">
                      <Link href={n.href} className="py-2 text-slate-100 hover:text-ember focus-visible:text-ember">{n.label}</Link>
                      {n.children && (
                        <ul className="invisible absolute left-0 top-full min-w-40 rounded-2xl border border-white/15 bg-ink/90 p-2 opacity-0 backdrop-blur-xl transition group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                          {n.children.map(c => <li key={c.href}><Link href={c.href} className="block whitespace-nowrap rounded-lg px-3 py-1.5 hover:bg-white/10">{c.label}</Link></li>)}
                        </ul>)}
                    </li>))}
                </ul>
              </nav>
            </GlassSurface>
          </div>
        )}
      </div>

      {/* phones / tablets: button + drop-down panel */}
      <div className="w-fit lg:hidden">
        <div className={`${pill} w-fit`}>{ibfBtn}</div>
        <div className={`absolute left-0 top-full mt-2 w-[min(86vw,20rem)] origin-top-left rounded-3xl border border-white/15 bg-[rgba(10,9,24,.88)] p-2 shadow-2xl backdrop-blur-xl transition duration-200 ${open ? "visible scale-100 opacity-100" : "invisible scale-95 opacity-0"}`}>
          <ul className="grid max-h-[70vh] gap-0.5 overflow-y-auto">
            {all.map(n => (
              <li key={n.label}>
                <Link href={n.href} className="block rounded-xl px-3 py-2.5 text-base font-medium text-slate-100 active:bg-white/10">{n.label}</Link>
                {n.children && (
                  <ul className="mb-1 ml-3 grid border-l border-white/10 pl-2">
                    {n.children.map(c => <li key={c.href}><Link href={c.href} className="block rounded-lg px-3 py-2 text-sm text-slate-300 active:bg-white/10">{c.label}</Link></li>)}
                  </ul>)}
              </li>))}
          </ul>
          <Link href={cta.href} className="mt-2 block rounded-full bg-volt px-5 py-3 text-center font-semibold text-white active:opacity-80">{cta.label}</Link>
        </div>
      </div>
    </div>);
}
