import Link from "next/link";
import GlassSurface from "./GlassSurface";

/** Liquid-glass pill button. tone tints the glass: "blue" (primary), "amber" (sponsor), "clear".
 *  Renders a link when `href` is given, otherwise a real <button> (forms, filters). */
const tints = { blue: "rgba(77,124,255,.38)", amber: "rgba(255,166,43,.42)", clear: "rgba(255,255,255,.06)" } as const;
type Props = {
  children: React.ReactNode; tone?: keyof typeof tints; height?: number; full?: boolean; className?: string;
  href?: string; external?: boolean;
  type?: "button" | "submit"; onClick?: () => void; disabled?: boolean; pressed?: boolean;
};
export default function GlassButton({ href, external, children, tone = "clear", height = 52, full, className = "", type = "button", onClick, disabled, pressed }: Props) {
  const cls = `${full ? "block w-full" : "inline-block"} rounded-full transition hover:scale-[1.04] focus-visible:outline focus-visible:outline-2 focus-visible:outline-ember disabled:opacity-60 disabled:hover:scale-100 ${className}`;
  const inner = (
    <GlassSurface width={full ? "100%" : "auto"} height={height} borderRadius={height / 2} backgroundOpacity={0.1} distortionScale={-120} displace={0.4} style={{ background: tints[tone] }}>
      <span className={`whitespace-nowrap px-5 font-semibold text-white ${height < 48 ? "text-sm" : ""}`}>{children}</span>
    </GlassSurface>);
  if (href) {
    return external
      ? <a href={href} target="_blank" rel="noopener noreferrer" className={cls}>{inner}</a>
      : <Link href={href} className={cls}>{inner}</Link>;
  }
  return <button type={type} onClick={onClick} disabled={disabled} aria-pressed={pressed} className={cls}>{inner}</button>;
}
