/** Text laid over the left side of the hero video (the video itself only carries the logo).
 *  Sizes use container-query units (cqw) so the block scales with the video; hidden on phones where it would be too small to read. */
const features = [
  { label: ["Blockchain", "Education"], d: "M12 3l7 4v6l-7 4-7-4V7l7-4zM12 11V3M5 7l7 4 7-4" },
  { label: ["Crypto", "Community"], d: "M12 3a9 9 0 100 18 9 9 0 000-18zM9.5 8h3.2a1.8 1.8 0 010 3.6H9.5m0 0h3.6a1.8 1.8 0 010 3.6H9.5M9.5 7v10M11.5 6v2M11.5 16v2" },
  { label: ["Real-World", "Projects"], d: "M9 18h6M10 21h4M12 3a6 6 0 00-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0012 3z" },
  { label: ["Industry", "Networks"], d: "M12 11a3 3 0 100-6 3 3 0 000 6zM5 20c0-3 3-5 7-5s7 2 7 5M4.5 12a2.3 2.3 0 100-4.6M19.5 12a2.3 2.3 0 110-4.6" },
];
export default function HeroText() {
  return (<>
    <div className="pointer-events-none absolute inset-0 hidden flex-col justify-between pb-[2cqw] pl-[5cqw] pt-[11cqw] md:flex">
      <div style={{ width: "40%" }}>
        <p className="font-medium uppercase text-sky-200/70" style={{ fontSize: "0.85cqw", letterSpacing: "0.32em" }}>Learn / Build / Connect / Grow</p>
        <p className="mt-[1.4cqw] font-display font-bold uppercase leading-[1.04] text-white" style={{ fontSize: "3.3cqw" }}>
          India Blockchain<br />Federation <span className="text-[#e6b94a]">Club</span>
        </p>
        <p className="mt-[0.9cqw] uppercase text-white/90" style={{ fontSize: "1.45cqw", letterSpacing: "0.3em" }}>At Bennett University</p>
        <p className="mt-[1.8cqw] max-w-[85%] text-sky-100/80" style={{ fontSize: "1.1cqw", lineHeight: 1.5 }}>
          Exploring the future of finance, technology and decentralization&nbsp;— together.
        </p>
      </div>
      <ul className="hidden lg:flex" style={{ gap: "1.4cqw" }}>
        {features.map((f, i) => (
          <li key={f.label[0]} className="flex flex-col items-center text-center" style={{ borderLeft: i ? "1px solid rgba(255,255,255,.18)" : "none", paddingLeft: i ? "1.4cqw" : 0, width: i ? "7.6cqw" : "6.2cqw" }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="#e6b94a" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden style={{ width: "2.6cqw", height: "2.6cqw" }}><path d={f.d} /></svg>
            <span className="mt-[0.5cqw] uppercase text-white/85" style={{ fontSize: "0.75cqw", lineHeight: 1.25, letterSpacing: "0.03em" }}>{f.label[0]}<br />{f.label[1]}</span>
          </li>))}
      </ul>
      <ul className="hidden uppercase text-white/60 lg:block" style={{ fontSize: "0.7cqw", letterSpacing: "0.25em", lineHeight: 2.1, borderLeft: "2px solid #e6b94a", paddingLeft: "1.1cqw", width: "fit-content" }}>
        <li>Decentralization</li><li>Innovation</li><li>Global Impact</li>
      </ul>
    </div>

    {/* phones: the video is too short to overlay text on, so the same text sits right under it */}
    <div className="px-4 pb-2 pt-5 text-left md:hidden">
      <p className="text-[11px] font-medium uppercase tracking-[0.28em] text-sky-200/70">Learn / Build / Connect / Grow</p>
      <p className="mt-3 font-display text-[1.85rem] font-bold uppercase leading-[1.08] text-white">India Blockchain Federation <span className="text-[#e6b94a]">Club</span></p>
      <p className="mt-2 text-sm uppercase tracking-[0.25em] text-white/90">At Bennett University</p>
      <p className="mt-4 text-base leading-relaxed text-sky-100/80">Exploring the future of finance, technology and decentralization&nbsp;— together.</p>
      <ul className="mt-5 grid grid-cols-2 gap-x-3 gap-y-4">
        {features.map(f => (
          <li key={f.label[0]} className="flex items-center gap-3">
            <svg viewBox="0 0 24 24" fill="none" stroke="#e6b94a" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden className="h-9 w-9 shrink-0"><path d={f.d} /></svg>
            <span className="text-xs uppercase leading-tight text-white/85">{f.label[0]}<br />{f.label[1]}</span>
          </li>))}
      </ul>
      <ul className="mt-5 w-fit border-l-2 border-[#e6b94a] pl-3 text-xs uppercase leading-7 tracking-[0.22em] text-white/60">
        <li>Decentralization</li><li>Innovation</li><li>Global Impact</li>
      </ul>
    </div>
  </>);
}
