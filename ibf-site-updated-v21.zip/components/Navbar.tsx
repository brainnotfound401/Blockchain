import { nav } from "@/data/site";
import ExpandNav from "./ExpandNav";

// Collapsed to a floating "IBF" button; clicking it expands the full top bar, moving the mouse away collapses it again.
export default function Navbar() {
  return (
    <header className="pointer-events-none sticky top-2 z-50 -mb-[38px] px-3 sm:top-3 sm:px-4">
      <div className="mx-auto max-w-6xl">
        <ExpandNav items={nav} cta={{ label: "Join IBF", href: "/join" }} />
      </div>
    </header>);
}
