import PageTitle from "./PageTitle";
export default function Page({ title, intro, children }: { title: string; intro?: string; children?: React.ReactNode }) {
  return (<div className="mx-auto max-w-6xl px-4 pb-12 pt-24 md:pb-16 md:pt-28"><PageTitle title={title} intro={intro} />
    <div className="mt-12 grid gap-10">{children}</div></div>);
}
