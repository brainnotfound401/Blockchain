"use client";
import { usePathname } from "next/navigation";
import { RetroGrid } from "./ui/retro-grid";
import { SmokeBackground } from "./ui/smoke-background";

/** Background for every page except the home page: purple glow + retro grid + mouse-follow smoke, across the top of the page. */
export default function PageBackdrop() {
  if (usePathname() === "/") return null;
  return (
    <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 z-0 h-[90vh] overflow-hidden">
      <div className="absolute top-0 h-full w-full bg-purple-950/10 bg-[radial-gradient(ellipse_20%_80%_at_50%_-20%,rgba(120,119,198,0.3),rgba(255,255,255,0))]" />
      <RetroGrid angle={65} cellSize={50} opacity={0.4} lineColor="#2f2e52" />
      <SmokeBackground />
    </div>
  );
}
