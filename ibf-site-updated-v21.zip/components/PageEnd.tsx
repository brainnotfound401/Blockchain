"use client";
import { usePathname } from "next/navigation";
import { CinematicFooter } from "./ui/motion-footer";

/** The curtain-reveal scroll animation at the end of every secondary page (the page scrolls away and reveals the footer underneath). */
export default function PageEnd() {
  if (usePathname() === "/") return null;
  return <CinematicFooter model={false} />;
}
