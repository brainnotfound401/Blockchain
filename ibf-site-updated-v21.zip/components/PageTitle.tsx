/** Page heading in the hero style: small glass badge, big fading-gradient title, muted description. */
export default function PageTitle({ title, intro, badge = "India Blockchain Federation Club" }: { title: string; intro?: string; badge?: string }) {
  return (
    <div className="mx-auto max-w-3xl space-y-5 text-center">
      <p className="group mx-auto w-fit rounded-3xl border-2 border-white/5 bg-gradient-to-tr from-zinc-300/5 via-gray-400/5 to-transparent px-5 py-2 text-sm text-gray-400">
        {badge}
        <svg className="ml-2 inline h-4 w-4 duration-300 group-hover:translate-x-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M9 18l6-6-6-6" /></svg>
      </p>
      <h1 className="bg-[linear-gradient(180deg,_#FFF_0%,_rgba(255,255,255,0.35)_160%)] bg-clip-text text-4xl font-bold tracking-tighter text-transparent md:text-6xl">{title}</h1>
      {intro && <p className="mx-auto max-w-2xl text-lg text-gray-300">{intro}</p>}
    </div>
  );
}
