"use client";

import * as React from "react";
import { useEffect, useRef } from "react";
import Link from "next/link";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

// Register ScrollTrigger safely for React
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

// tiny class joiner (replaces shadcn's `cn`, so no extra dependencies are needed)
const cn = (...parts: Array<string | false | null | undefined>) => parts.filter(Boolean).join(" ");

// -------------------------------------------------------------------------
// 1. THEME-ADAPTIVE INLINE STYLES (colours come from the CSS variables in globals.css)
// -------------------------------------------------------------------------
const STYLES = `
.cinematic-footer-wrapper {
  font-family: var(--font-body), sans-serif;
  -webkit-font-smoothing: antialiased;

  --pill-bg-1: color-mix(in oklch, var(--foreground) 3%, transparent);
  --pill-bg-2: color-mix(in oklch, var(--foreground) 1%, transparent);
  --pill-shadow: color-mix(in oklch, var(--background) 50%, transparent);
  --pill-highlight: color-mix(in oklch, var(--foreground) 10%, transparent);
  --pill-inset-shadow: color-mix(in oklch, var(--background) 80%, transparent);
  --pill-border: color-mix(in oklch, var(--foreground) 8%, transparent);

  --pill-bg-1-hover: color-mix(in oklch, var(--foreground) 8%, transparent);
  --pill-bg-2-hover: color-mix(in oklch, var(--foreground) 2%, transparent);
  --pill-border-hover: color-mix(in oklch, var(--foreground) 20%, transparent);
  --pill-shadow-hover: color-mix(in oklch, var(--background) 70%, transparent);
  --pill-highlight-hover: color-mix(in oklch, var(--foreground) 20%, transparent);
}

@keyframes footer-breathe {
  0% { transform: translate(-50%, -50%) scale(1); opacity: 0.6; }
  100% { transform: translate(-50%, -50%) scale(1.1); opacity: 1; }
}
@keyframes footer-scroll-marquee {
  from { transform: translateX(0); }
  to { transform: translateX(-50%); }
}
@keyframes footer-heartbeat {
  0%, 100% { transform: scale(1); filter: drop-shadow(0 0 5px color-mix(in oklch, var(--destructive) 50%, transparent)); }
  15%, 45% { transform: scale(1.2); filter: drop-shadow(0 0 10px color-mix(in oklch, var(--destructive) 80%, transparent)); }
  30% { transform: scale(1); }
}
.animate-footer-breathe { animation: footer-breathe 8s ease-in-out infinite alternate; }
.animate-footer-scroll-marquee { animation: footer-scroll-marquee 40s linear infinite; }
.animate-footer-heartbeat { animation: footer-heartbeat 2s cubic-bezier(0.25, 1, 0.5, 1) infinite; }



/* Falling dollar bills (pure CSS 3D + GSAP, no external model) */
.money-bill { position: absolute; top: 0; transform-style: preserve-3d; will-change: transform; }
.money-face {
  position: absolute; inset: 0; display: grid; place-items: center; border-radius: 6px; backface-visibility: hidden; -webkit-backface-visibility: hidden;
  background: linear-gradient(135deg, #cfcfcb 0%, #e6e6e2 48%, #c6c6c2 100%);
  box-shadow: inset 0 0 0 3px #ffffff, inset 0 0 0 4px #111, inset 0 0 0 6px #ffffff, inset 0 0 0 7px #111, 0 6px 18px rgba(0,0,0,.4);
  color: #111; font-weight: 900;
}
.money-face::before { content: ""; position: absolute; width: 38%; aspect-ratio: 1; border-radius: 50%; border: 2px solid #111; background: repeating-radial-gradient(circle, rgba(0,0,0,.08) 0 2px, transparent 2px 5px); }
.money-face span { position: relative; font-size: 1.9em; line-height: 1; text-shadow: none; }
.money-face i { position: absolute; font-style: normal; font-size: .62em; font-weight: 800; opacity: .9; }
.money-face i:nth-of-type(1) { left: 7%; top: 8%; } .money-face i:nth-of-type(2) { right: 7%; bottom: 8%; }
.money-back { transform: rotateY(180deg); }

/* Grid background */
.footer-bg-grid {
  background-size: 60px 60px;
  background-image:
    linear-gradient(to right, color-mix(in oklch, var(--foreground) 3%, transparent) 1px, transparent 1px),
    linear-gradient(to bottom, color-mix(in oklch, var(--foreground) 3%, transparent) 1px, transparent 1px);
  mask-image: linear-gradient(to bottom, transparent, black 30%, black 70%, transparent);
  -webkit-mask-image: linear-gradient(to bottom, transparent, black 30%, black 70%, transparent);
}

/* Aurora glow */
.footer-aurora {
  background: radial-gradient(circle at 50% 50%,
    color-mix(in oklch, var(--primary) 20%, transparent) 0%,
    color-mix(in oklch, var(--secondary) 18%, transparent) 40%,
    transparent 70%);
}

/* Glass pills */
.footer-glass-pill {
  background: linear-gradient(145deg, var(--pill-bg-1) 0%, var(--pill-bg-2) 100%);
  box-shadow: 0 10px 30px -10px var(--pill-shadow), inset 0 1px 1px var(--pill-highlight), inset 0 -1px 2px var(--pill-inset-shadow);
  border: 1px solid var(--pill-border);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  transition: background 0.4s cubic-bezier(0.16, 1, 0.3, 1), border-color 0.4s, box-shadow 0.4s, color 0.3s; /* not 'all', so the GSAP magnetic transform isn't delayed */
}
.footer-glass-pill:hover {
  background: linear-gradient(145deg, var(--pill-bg-1-hover) 0%, var(--pill-bg-2-hover) 100%);
  border-color: var(--pill-border-hover);
  box-shadow: 0 20px 40px -10px var(--pill-shadow-hover), inset 0 1px 1px var(--pill-highlight-hover);
  color: var(--foreground);
}

/* Giant background word */
.footer-giant-bg-text {
  font-family: var(--font-display), sans-serif;
  font-size: 34vw;
  line-height: 0.75;
  font-weight: 900;
  letter-spacing: -0.05em;
  color: transparent;
  -webkit-text-stroke: 1px color-mix(in oklch, var(--foreground) 8%, transparent);
  background: linear-gradient(180deg, color-mix(in oklch, var(--foreground) 12%, transparent) 0%, transparent 60%);
  -webkit-background-clip: text;
  background-clip: text;
}

/* Metallic heading */
.footer-text-glow {
  font-family: var(--font-display), sans-serif;
  background: linear-gradient(180deg, var(--foreground) 0%, color-mix(in oklch, var(--foreground) 40%, transparent) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  filter: drop-shadow(0px 0px 20px color-mix(in oklch, var(--foreground) 15%, transparent));
}

/* Diagonal marquee strip + its stars */
.footer-marquee {
  border-top: 1px solid color-mix(in oklch, var(--foreground) 12%, transparent);
  border-bottom: 1px solid color-mix(in oklch, var(--foreground) 12%, transparent);
  background: color-mix(in oklch, var(--background) 60%, transparent);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
}
.footer-star-a { color: color-mix(in oklch, var(--primary) 70%, transparent); }
.footer-star-b { color: color-mix(in oklch, var(--secondary) 70%, transparent); }
`;

// -------------------------------------------------------------------------
// 2. MAGNETIC BUTTON PRIMITIVE
// -------------------------------------------------------------------------
export type MagneticButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> &
  React.AnchorHTMLAttributes<HTMLAnchorElement> & {
    as?: React.ElementType;
  };

const MagneticButton = React.forwardRef<HTMLElement, MagneticButtonProps>(
  ({ className, children, as: Component = "button", ...props }, forwardedRef) => {
    const localRef = useRef<HTMLElement>(null);

    useEffect(() => {
      if (typeof window === "undefined") return;
      const element = localRef.current;
      if (!element) return;
      // no magnetic tilt on touch screens
      if (window.matchMedia("(hover: none)").matches) return;

      const ctx = gsap.context(() => {
        const handleMouseMove = (e: MouseEvent) => {
          const rect = element.getBoundingClientRect();
          const h = rect.width / 2;
          const w = rect.height / 2;
          const x = e.clientX - rect.left - h;
          const y = e.clientY - rect.top - w;

          gsap.to(element, {
            x: x * 0.4,
            y: y * 0.4,
            rotationX: -y * 0.15,
            rotationY: x * 0.15,
            scale: 1.05,
            ease: "power2.out",
            duration: 0.4,
          });
        };

        const handleMouseLeave = () => {
          gsap.to(element, { x: 0, y: 0, rotationX: 0, rotationY: 0, scale: 1, ease: "elastic.out(1, 0.3)", duration: 1.2 });
        };

        element.addEventListener("mousemove", handleMouseMove as EventListener);
        element.addEventListener("mouseleave", handleMouseLeave);

        return () => {
          element.removeEventListener("mousemove", handleMouseMove as EventListener);
          element.removeEventListener("mouseleave", handleMouseLeave);
        };
      }, element);

      return () => ctx.revert();
    }, []);

    return (
      <Component
        ref={(node: HTMLElement) => {
          (localRef as React.MutableRefObject<HTMLElement | null>).current = node;
          if (typeof forwardedRef === "function") forwardedRef(node);
          else if (forwardedRef) (forwardedRef as React.MutableRefObject<HTMLElement | null>).current = node;
        }}
        className={cn("cursor-pointer", className)}
        {...props}
      >
        {children}
      </Component>
    );
  }
);
MagneticButton.displayName = "MagneticButton";

// -------------------------------------------------------------------------
// 3. MAIN COMPONENT
// -------------------------------------------------------------------------
// deterministic pseudo-random numbers (same on server and client, so no hydration mismatch)
const rnd = (i: number, k: number) => { const x = Math.sin(i * 12.9898 + k * 78.233) * 43758.5453; return x - Math.floor(x); };
const BILLS = Array.from({ length: 26 }, (_, i) => {
  const depth = rnd(i, 1);                                   // 0 = far/small/faint, 1 = near/big
  return { left: rnd(i, 2) * 92 + 2, rest: rnd(i, 3) * 78 + 4, w: 70 + depth * 90, op: 0.12 + depth * 0.2, blur: (1 - depth) * 2.2,
           rx: (rnd(i, 4) - 0.5) * 140, ry: (rnd(i, 5) - 0.5) * 140, rz: (rnd(i, 6) - 0.5) * 70, spin: (rnd(i, 7) > 0.5 ? 1 : -1) * (180 + rnd(i, 8) * 360), delay: rnd(i, 9) * 0.5 };
});
const Bill = () => (<>
  <div className="money-face"><i>100</i><span>$</span><i>100</i></div>
  <div className="money-face money-back"><i>100</i><span>$</span><i>100</i></div>
</>);

const MODEL_UID = "a22f4052e96b4c7fa5c693365a434215";   // Sketchfab "DOLLARS MONEY" by DTA Design Studio
const VIEWER_API = "https://static.sketchfab.com/api/sketchfab-viewer-1.12.1.js";

const iconCls = "h-6 w-6 text-muted-foreground transition-colors group-hover:text-foreground";

export function CinematicFooter({ model: useModel = true }: { model?: boolean } = {}) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const giantTextRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const linksRef = useRef<HTMLDivElement>(null);
  const moneyRef = useRef<HTMLDivElement>(null);       // fallback bills
  const modelRef = useRef<HTMLDivElement>(null);       // sketchfab model wrapper (falls on scroll)
  const frameRef = useRef<HTMLIFrameElement>(null);
  const [model, setModel] = React.useState<"loading" | "ready" | "failed">(useModel ? "loading" : "failed");

  // Load the Sketchfab model through its viewer API. If it can't be shown (blocked / 403 / too slow), switch to the built-in falling bills.
  useEffect(() => {
    if (!useModel) return;   // secondary pages: skip the heavy 3D model and show the built-in falling notes
    let done = false;
    const fail = () => { if (!done) { done = true; setModel("failed"); } };
    const timer = window.setTimeout(fail, 20000);
    const start = () => {
      const SF = (window as any).Sketchfab;
      if (!SF || !frameRef.current) return fail();
      try {
        const client = new SF(frameRef.current);
        client.init(MODEL_UID, {
          autostart: 1, transparent: 1, preload: 1, dnt: 1, ui_theme: "dark", autospin: 0.15,
          ui_controls: 0, ui_infos: 0, ui_inspector: 0, ui_stop: 0, ui_watermark: 0, ui_hint: 0, ui_help: 0, ui_settings: 0, ui_vr: 0, ui_fullscreen: 0, ui_annotations: 0, ui_ar: 0,
          success: (api: any) => { api.start(); try { api.getMaterialList((e: unknown, m: unknown) => { if (!e) console.log("[money model] materials", m); }); } catch {} api.addEventListener("viewerready", () => { if (!done) { done = true; window.clearTimeout(timer); setModel("ready"); } }); },
          error: fail,
        });
      } catch { fail(); }
    };
    if ((window as any).Sketchfab) start();
    else {
      const sc = document.createElement("script");
      sc.src = VIEWER_API; sc.async = true; sc.onload = start; sc.onerror = fail;
      document.head.appendChild(sc);
    }
    return () => { window.clearTimeout(timer); done = true; };
  }, []);
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!wrapperRef.current) return;

    // React strict mode compatible GSAP context cleanup
    const ctx = gsap.context(() => {
      // Background parallax
      gsap.fromTo(
        giantTextRef.current,
        { y: "10vh", scale: 0.8, opacity: 0 },
        { y: "0vh", scale: 1, opacity: 1, ease: "power1.out",
          scrollTrigger: { trigger: wrapperRef.current, start: "top 80%", end: "bottom bottom", scrub: 1 } }
      );

      // Sketchfab model falls in with the scroll
      gsap.fromTo(
        modelRef.current,
        { y: "-90vh", rotation: -6, scale: 1.1, opacity: 0.02 },
        { y: "0vh", rotation: 0, scale: 1, opacity: 0.22, ease: "power2.out",
          scrollTrigger: { trigger: wrapperRef.current, start: "top 95%", end: "top 15%", scrub: 1 } }
      );

      // Fallback bills fall in first (starts earlier than the text), tumbling down and settling behind everything
      gsap.utils.toArray<HTMLElement>(".money-bill", moneyRef.current).forEach((el, i) => {
        const b = BILLS[i];
        gsap.fromTo(
          el,
          { y: "-130vh", rotationX: b.rx + b.spin, rotationY: b.ry + b.spin, rotationZ: b.rz - 40, opacity: 0, transformPerspective: 700 },
          { y: `${b.rest}vh`, rotationX: b.rx, rotationY: b.ry, rotationZ: b.rz, opacity: b.op, ease: "power2.out",
            scrollTrigger: { trigger: wrapperRef.current, start: `top ${98 - b.delay * 20}%`, end: `top ${20 + b.delay * 10}%`, scrub: 1 } }
        );
      });

      // Staggered content reveal
      gsap.fromTo(
        [headingRef.current, linksRef.current],
        { y: 50, opacity: 0 },
        { y: 0, opacity: 1, stagger: 0.15, ease: "power3.out",
          scrollTrigger: { trigger: wrapperRef.current, start: "top 40%", end: "bottom bottom", scrub: 1 } }
      );
    }, wrapperRef);

    const refresh = window.setTimeout(() => ScrollTrigger.refresh(), 400);
    return () => { window.clearTimeout(refresh); ctx.revert(); };
  }, []);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: STYLES }} />

      {/* "Curtain reveal" wrapper: the clip-path limits the fixed footer to this box, so it is revealed as you scroll past */}
      <div
        ref={wrapperRef}
        aria-label="Join IBF"
        className="relative h-[100svh] w-full"
        style={{ clipPath: "polygon(0% 0, 100% 0%, 100% 100%, 0 100%)" }}
      >
        <section className="cinematic-footer-wrapper fixed bottom-0 left-0 flex h-[100svh] w-full flex-col justify-between overflow-hidden bg-background text-foreground">

          {/* Ambient light & grid */}
          <div className="footer-aurora pointer-events-none absolute left-1/2 top-1/2 z-0 h-[60vh] w-[80vw] -translate-x-1/2 -translate-y-1/2 animate-footer-breathe rounded-[50%] blur-[80px]" />
          <div className="footer-bg-grid pointer-events-none absolute inset-0 z-0" />

          {/* Giant background word */}
          <div
            ref={giantTextRef}
            aria-hidden
            className="footer-giant-bg-text pointer-events-none absolute -bottom-[5vh] left-1/2 z-0 -translate-x-1/2 select-none whitespace-nowrap"
          >
            IBF
          </div>

          {/* 1. Falling money in the background, behind the text and design: the Sketchfab 3D model, or (if Sketchfab blocks it) built-in bills */}
          <div ref={modelRef} aria-hidden className="pointer-events-none absolute inset-0 z-[5] will-change-transform" style={{ opacity: 0.02, display: model === "failed" ? "none" : undefined }}>
            <iframe ref={frameRef} title="Dollars money 3D model" frameBorder={0} allowFullScreen tabIndex={-1} allow="autoplay; fullscreen; xr-spatial-tracking"
              {...{ "xr-spatial-tracking": "", "execution-while-out-of-viewport": "", "execution-while-not-rendered": "", "web-share": "" }}
              className="h-full w-full border-0 transition-opacity duration-700" style={{ opacity: model === "ready" ? 1 : 0, filter: "grayscale(1) brightness(1.2) contrast(1.6)" }} />
          </div>
          <div ref={moneyRef} aria-hidden className="pointer-events-none absolute inset-0 z-[5] overflow-hidden" style={{ visibility: model === "failed" ? "visible" : "hidden" }}>
            {BILLS.map((b, i) => (
              <div key={i} className="money-bill" style={{ left: `${b.left}%`, width: b.w, height: b.w * 0.46, fontSize: b.w * 0.16, opacity: 0, filter: `blur(${b.blur}px)` }}>
                <Bill />
              </div>
            ))}
          </div>
          {/* soft dark veil so the text stays readable */}
          <div aria-hidden className="pointer-events-none absolute inset-0 z-[6] bg-gradient-to-b from-background/30 via-transparent to-background/45" />

          {/* 2. Centre content */}
          <div className="relative z-10 mx-auto mt-20 flex w-full max-w-5xl flex-1 flex-col items-center justify-center px-6">
            <h2
              ref={headingRef}
              className="footer-text-glow mb-10 text-center text-3xl font-black tracking-tighter sm:text-4xl md:mb-12 md:text-6xl lg:text-7xl"
            >
              Decentralizing the Future, One Block at a Time.
            </h2>

            <div ref={linksRef} className="flex w-full flex-col items-center gap-6">
              {/* primary actions */}
              <div className="flex w-full flex-wrap justify-center gap-4">
                <MagneticButton as={Link} href="/join" className="footer-glass-pill group flex items-center gap-3 rounded-full px-8 py-4 text-sm font-bold text-foreground md:px-10 md:py-5 md:text-base">
                  <svg className={iconCls} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden><circle cx="9" cy="8" r="3.2" /><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6" /><path d="M16 5.2a3.2 3.2 0 010 5.6M18 14.4c1.8.8 3 2.6 3 4.6" /></svg>
                  Join IBF
                </MagneticButton>

                <MagneticButton as={Link} href="/events" className="footer-glass-pill group flex items-center gap-3 rounded-full px-8 py-4 text-sm font-bold text-foreground md:px-10 md:py-5 md:text-base">
                  <svg className={iconCls} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden><rect x="3.5" y="5" width="17" height="15" rx="2.5" /><path d="M3.5 10h17M8 3v4M16 3v4" /></svg>
                  Upcoming events
                </MagneticButton>
              </div>

              {/* secondary links */}
              <div className="mt-2 flex w-full flex-wrap justify-center gap-3 md:gap-6">
                {[["Sponsorship", "/sponsorship"], ["Partners", "/partners"], ["Resources", "/resources"], ["Contact", "/contact"]].map(([label, href]) => (
                  <MagneticButton key={href} as={Link} href={href} className="footer-glass-pill rounded-full px-6 py-3 text-xs font-medium text-muted-foreground hover:text-foreground md:text-sm">
                    {label}
                  </MagneticButton>
                ))}
              </div>
            </div>
          </div>

          {/* 3. Bottom bar */}
          <div className="relative z-20 flex w-full flex-row items-center justify-between gap-4 px-6 pb-8 md:px-12">
            <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground md:text-xs">
              © 2026 IBF · India Blockchain Federation Club, Bennett University{model === "ready" && (<> · 3D model: <a href="https://sketchfab.com/3d-models/dollars-money-a22f4052e96b4c7fa5c693365a434215" target="_blank" rel="noopener noreferrer" className="hover:underline">Dollars Money</a> by <a href="https://sketchfab.com/dtadesignstudio" target="_blank" rel="noopener noreferrer" className="hover:underline">DTA Design Studio</a> on Sketchfab</>)}
            </div>

            <MagneticButton
              as="button"
              aria-label="Back to top"
              onClick={scrollToTop}
              className="footer-glass-pill group flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
            >
              <svg className="h-5 w-5 transform transition-transform duration-300 group-hover:-translate-y-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 10l7-7m0 0l7 7m-7-7v18" />
              </svg>
            </MagneticButton>
          </div>
        </section>
      </div>
    </>
  );
}

export default CinematicFooter;
