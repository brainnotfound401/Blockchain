import * as React from "react";

/** Perspective "retro" grid (adapted from the hero-section-dark component; dark theme only, no extra dependencies). */
export function RetroGrid({ angle = 65, cellSize = 60, opacity = 0.5, lineColor = "#2a2a2a" }: { angle?: number; cellSize?: number; opacity?: number; lineColor?: string }) {
  const style = { "--grid-angle": `${angle}deg`, "--cell-size": `${cellSize}px`, "--opacity": opacity, "--line": lineColor } as React.CSSProperties;
  return (
    <div className="pointer-events-none absolute size-full overflow-hidden [perspective:200px] opacity-[var(--opacity)]" style={style}>
      <div className="absolute inset-0 [transform:rotateX(var(--grid-angle))]">
        <div className="animate-grid [background-image:linear-gradient(to_right,var(--line)_1px,transparent_0),linear-gradient(to_bottom,var(--line)_1px,transparent_0)] [background-repeat:repeat] [background-size:var(--cell-size)_var(--cell-size)] [height:300vh] [inset:0%_0px] [margin-left:-200%] [transform-origin:100%_0_0] [width:600vw]" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-ink to-transparent to-90%" />
    </div>
  );
}
