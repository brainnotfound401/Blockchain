"use client";
import React, { useEffect, useRef } from "react";

/** Mouse-follow smoke (adapted from the smoke-card component) used as a page background.
 *  The canvas ignores pointer events, so content on top stays clickable; the mouse is tracked on the window. */
class Particle {
  x: number; y: number; size: number; speedX: number; speedY: number; life = 100; initialSize: number;
  constructor(x: number, y: number) {
    this.x = x; this.y = y;
    this.size = Math.random() * 5 + 2; this.initialSize = this.size;
    this.speedX = Math.random() * 2 - 1; this.speedY = -Math.random() * 3 - 1;
  }
  update() { this.x += this.speedX; this.y += this.speedY; this.life -= 1; this.size = Math.max(0, this.initialSize * (this.life / 100)); }
}

export function SmokeBackground({ className = "" }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let particles: Particle[] = [];
    let mouse: { x: number; y: number } | null = null;
    let raf = 0;

    const resize = () => { const r = canvas.getBoundingClientRect(); canvas.width = r.width; canvas.height = r.height; };
    const move = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      const x = e.clientX - r.left, y = e.clientY - r.top;
      mouse = x >= 0 && y >= 0 && x <= r.width && y <= r.height ? { x, y } : null;
    };
    const leave = () => { mouse = null; };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles = particles.filter(p => p.life > 0 && p.size > 0);
      for (const p of particles) {
        p.update();
        if (p.size <= 0) continue;
        ctx.fillStyle = `rgba(150, 160, 210, ${(p.life / 100) * 0.55})`;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
      }
      if (mouse && particles.length < 500) {
        for (let i = 0; i < 2; i++) particles.push(new Particle(mouse.x + (Math.random() * 10 - 5), mouse.y + (Math.random() * 10 - 5)));
      }
      raf = requestAnimationFrame(animate);
    };

    resize();
    window.addEventListener("resize", resize);
    window.addEventListener("pointermove", move);
    document.documentElement.addEventListener("mouseleave", leave);
    animate();
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", move);
      document.documentElement.removeEventListener("mouseleave", leave);
    };
  }, []);

  return <canvas ref={canvasRef} aria-hidden className={`pointer-events-none absolute inset-0 h-full w-full ${className}`} />;
}
