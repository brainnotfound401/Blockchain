import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { ink: "#07060F", volt: "#4D7CFF", violet: "#8B5CF6", ember: "#FFA62B",
      background: "var(--background)", foreground: "var(--foreground)", "muted-foreground": "var(--muted-foreground)", destructive: "var(--destructive)" },
    keyframes: { grid: { "0%": { transform: "translateY(-50%)" }, "100%": { transform: "translateY(0)" } } },
    animation: { grid: "grid 15s linear infinite" },
    fontFamily: { display: ["var(--font-display)"], body: ["var(--font-body)"] },
  } },
} satisfies Config;
